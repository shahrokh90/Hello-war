﻿var t_coefficient = 1;//ضریب مقادیر است 1 , 10,100
//append to functions
var infant_no_rule_f_game_waiting = game_waiting;
var infant_no_rule_f_game_busted = game_busted;
var infant_no_rule_f_game_update = game_update;
var infant_no_rule_f_game_cash_out = game_cash_out;
var box =document.getElementsByClassName('game-controls')[0];
//elements
var t_cashoutProduct = document.getElementsByClassName('cashout-amount')[0];
var t_priceAmount = document.getElementsByClassName('game-amount')[0];
var t_setCashBtn = document.getElementsByClassName("place-bet")[0];//دکمه ثبت
var t_setCashCancelBtn = document.getElementsByClassName("place-bet-cancel")[0];//دکمه کنسل
var h_information = $('div.user-name');


// var t_remain = $("div.top-link chips-amount");//مقدار باقی مانده ما
var infant_no_rule_counter = 0;
var infant_no_rule_damage=0;
var infant_no_rule_primaryBet=10;
var infant_no_rule_betValue=infant_no_rule_primaryBet;
var infant_no_rule_primaryBetCoe=1.50;
var infant_no_rule_betCoe=1.50;
var infant_no_rule_constant_min_wait_value=1;
var infant_no_rule_constant_max_wait_value=5;
var infant_no_rule_current_wait_value=0;
var infant_no_rule_wait_for_green=0;
var infant_no_rule_enable_crash=0;
//
var infant_no_rule_kamtarin_coe=1.10;
var infant_no_rule_bishtarin_coe=1.30;
var infant_no_rule_random_bridge=1/(infant_no_rule_bishtarin_coe-infant_no_rule_kamtarin_coe);
var infant_no_rule_min_bet=10;
var infant_no_rule_max_bet=100;
var infant_no_rule_middle_coe=1.87;
var infant_no_rule_low_middle_coe=1.50;
var infant_no_rule_hi_middle_coe=2.50;
function infant_no_rule_getCondition( infant_no_rule_counter) {
	infant_no_rule_random_bridge=1/(infant_no_rule_bishtarin_coe-infant_no_rule_kamtarin_coe);
	if(infant_no_rule_current_wait_value===0 && infant_no_rule_wait_for_green===0){
		if(infant_no_rule_damage===0){
			infant_no_rule_primaryBetCoe=(Math.random()/infant_no_rule_random_bridge)+infant_no_rule_kamtarin_coe;
			infant_no_rule_betCoe=infant_no_rule_primaryBetCoe;
			infant_no_rule_betCoe=infant_no_rule_betCoe.toFixed(2);
			infant_no_rule_primaryBet=Math.floor((Math.random()*(infant_no_rule_max_bet-infant_no_rule_min_bet)))+infant_no_rule_min_bet;
			infant_no_rule_betValue=infant_no_rule_primaryBet;
		}else{
			infant_no_rule_betCoe= (Math.random()/infant_no_rule_random_bridge)+infant_no_rule_kamtarin_coe;
			infant_no_rule_betCoe=infant_no_rule_betCoe.toFixed(2);
			infant_no_rule_betValue=Math.floor((infant_no_rule_damage)/(infant_no_rule_betCoe-1)+infant_no_rule_primaryBet*(infant_no_rule_primaryBetCoe-1)/(infant_no_rule_betCoe-1))+1;
		}
		t_cashoutProduct.value = infant_no_rule_betCoe;
		t_priceAmount.value = infant_no_rule_betValue * t_coefficient;
		t_setCashBtn.click();
		console.log("%c bet "+(infant_no_rule_betValue * t_coefficient)+" on "+infant_no_rule_betCoe,'color: #01de43');
	}else{
		console.log("%c wait ",'color: #019043');
	}
}

game_waiting = (function () {
    return function (str) {
		//infant_no_rule_H_addOption();
		if(infant_no_rule_enable_crash===1){
        //console.log("game_waiting ", str);
        infant_no_rule_getInformation();
        infant_no_rule_getCondition(infant_no_rule_counter); //game wating
        }
		infant_no_rule_f_game_waiting.apply(this, arguments); // calling the real function
    };
}());

game_busted = (function () {
    return function (str) {
		if(infant_no_rule_enable_crash===1){
        var currentValue = str.amount / 100;
		   console.log('%c bust on '+currentValue,'color: #ff040b');
		   if(infant_no_rule_current_wait_value===0){
			   if(infant_no_rule_wait_for_green===0){
				   if(currentValue<1.21){
					   infant_no_rule_current_wait_value=Math.floor((Math.random()*(infant_no_rule_constant_max_wait_value-infant_no_rule_constant_min_wait_value)))+infant_no_rule_constant_min_wait_value;
				   }
					if (currentValue >= infant_no_rule_betCoe) {
						infant_no_rule_damage=0;
						infant_no_rule_counter=0;
					} else {
						infant_no_rule_counter++;
						infant_no_rule_damage += infant_no_rule_betValue;
						infant_no_rule_wait_for_green=1;
						infant_no_rule_middle_coe=(Math.random()*(infant_no_rule_hi_middle_coe-infant_no_rule_low_middle_coe))+infant_no_rule_low_middle_coe;
					}
			   }else{
				   if(currentValue>infant_no_rule_middle_coe){
				   infant_no_rule_wait_for_green=0;
				   } 
			   }
		   }else{
			   infant_no_rule_current_wait_value--;
		   }
		}
		infant_no_rule_f_game_busted.apply(this, arguments); // calling the real function
    };
}());




game_update = (function () {
    return function (str) {
		if(infant_no_rule_enable_crash===1){
		}
		infant_no_rule_f_game_update.apply(this, arguments); // calling the real function
    };
}());

game_cash_out = (function () {
    return function (str) {
		if(infant_no_rule_enable_crash===1){
		}
		infant_no_rule_f_game_cash_out.apply(this, arguments); // calling the real function
    };
}());
//-------------------
function infant_no_rule_getInformation(){
   var str = " <b style='color:red'>  ( @enfejar_rayegan ):" + (infant_no_rule_counter) + "</b> | ";
    str += " <b style='color:brown'>   id chanel ( @enfejar_rayegan ) :" + (infant_no_rule_damage) + "</b> | ";
    str += " <b style='color:blue'>  سود :   " + h_profit() + "</b> | ";
    $("h4#hadi-box").html(str);
}


//-----add option
function infant_no_rule_H_addOption() {
     var h_option_text='<input id="conficient" class="main_amir" type="number" onchange="addConficient()" style="width:50px" placeholder="صریب بازی" value="' + t_coefficient + '">';
	h_option_text +='<span class="t1" style="color:red" > min coe</span>';
	h_option_text +='<input id="min_zarib" style="width:50px" class="t2" type="number" onchange="infant_no_rule_update_min_zarib()" placeholder="صریب مین" value="' + infant_no_rule_kamtarin_coe + '">';
	h_option_text +='<span class="t3" style="color:green" > max coe</span>';
	h_option_text +='<input id="max_zarib" style="width:50px" class="t4" type="number" onchange="infant_no_rule_update_max_zarib()" placeholder="صریب ماکس" value="' + infant_no_rule_bishtarin_coe + '">';
	h_option_text +='<span class="t5" style="color:red" > min bet</span>';
	h_option_text +='<input id="infant_no_rule_min_bet" style="width:60px" class="t6" type="number" onchange="update_infant_no_rule_min_bet()" placeholder="مین بت اول" value="' + infant_no_rule_min_bet + '">';
	h_option_text +='<span class="t7" style="color:green" > max bet</span>';
	h_option_text +='<input id="infant_no_rule_max_bet" style="width:60px" class="t8" type="number" onchange="update_infant_no_rule_max_bet()" placeholder="مکس بت اول" value="' + infant_no_rule_max_bet + '">';
	h_option_text +='<span class="t9" style="color:purple" >min wait:</span>';
	h_option_text +='<input id="min_wait_hand" style="width:45px" class="t10" type="number" onchange="update_infant_no_rule_constant_min_wait_value()" placeholder="صبر" value="' + infant_no_rule_constant_min_wait_value + '">';
	h_option_text +='<span class="t11" style="color:purple" >max wait:</span>';
	h_option_text +='<input id="max_wait_hand" style="width:45px" class="t12" type="number" onchange="update_infant_no_rule_constant_max_wait_value()" placeholder="صبر" value="' + infant_no_rule_constant_max_wait_value + '">';
    //h_option_text += '<select onchange="changeConf()" id="change-method">';
   // h_option_text += '<option value="3">3</option>';
    //h_option_text += '<option value="4.01">4</option>';
    //h_option_text += '<option value="5">5</option></select>';
    //$('div.top-link.user-name').html(h_option_text);
	$('span.t1').remove();
	$('span.t3').remove();
	$('span.t5').remove();
	$('span.t7').remove();
	$('span.t9').remove();
	$('span.t11').remove();
	$('input.t2').remove();
	$('input.t4').remove();
	$('input.t6').remove();
	$('input.t8').remove();
	$('input.t10').remove();
	$('input.t12').remove();
	$('input.main_amir').remove();
	$('button.pause_btn').remove();
	$('button.resume_btn').remove();
    $('div.top-bar').prepend(h_option_text);
}
function infant_no_rule_add_side_bar(){
	var side_bar='<div id="mySidenav" class="sidenav">';
  side_bar+='<a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>';
  side_bar+='<a href="#">کمترین ضریب<input id="min_zarib_id" onchange="infant_no_rule_update_item()" value="' + infant_no_rule_kamtarin_coe + '"></a>';
  side_bar+='<a href="#">بیشترین ضریب<input id="max_zarib_id" onchange="infant_no_rule_update_item()" value="' + infant_no_rule_bishtarin_coe + '"></a>';
  side_bar+='<a href="#">کمترین شرط<input id="infant_no_rule_min_bet_id" onchange="infant_no_rule_update_item()" value="' + infant_no_rule_min_bet + '"></a>';
  side_bar+='<a href="#">بیشترین شرط<input id="infant_no_rule_max_bet_id" onchange="infant_no_rule_update_item()" value="' + infant_no_rule_max_bet + '"></a>';
  side_bar+='<a href="#">کمترین توقف<input id="min_wait_hand_id" onchange="infant_no_rule_update_item()" value="' +infant_no_rule_constant_min_wait_value + '"></a>';
  side_bar+='<a href="#">بیشترین توقف<input id="max_wait_hand_id" onchange="infant_no_rule_update_item()" value="' + infant_no_rule_constant_max_wait_value + '"></a>';
  side_bar+='<a href="#">کمترین ضریب میانی<input id="low_middle_coe_id" onchange="infant_no_rule_update_item()" value="' + infant_no_rule_low_middle_coe + '"></a>';
  side_bar+='<a href="#">بیشترین ضریب میانی<input id="hi_middle_coe_id" onchange="infant_no_rule_update_item()" value="' + infant_no_rule_hi_middle_coe + '"></a>';
 // side_bar+='<a href="#">coe 10<input></input></a>';
 // side_bar+='<a href="#">coe 11<input></input></a>';
 // side_bar+='<a href="#">coe 12<input></input></a>';
 // side_bar+='<a href="#">coe 13<input></input></a>';
 // side_bar+='<a href="#">coe 14<input></input></a>';
 // side_bar+='<a href="#">coe 15<input></input></a>';
side_bar+='</div>';
$( ".top-bar" ).before( side_bar);
}
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
function infant_no_rule_update_item(){
	infant_no_rule_bishtarin_coe = $("input#max_zarib_id").val();
	infant_no_rule_bishtarin_coe= parseFloat(infant_no_rule_bishtarin_coe);
	
	infant_no_rule_kamtarin_coe = $("input#min_zarib_id").val();
	infant_no_rule_kamtarin_coe= parseFloat(infant_no_rule_kamtarin_coe);
	
	infant_no_rule_min_bet = $("input#infant_no_rule_min_bet_id").val();
	infant_no_rule_min_bet = parseInt(infant_no_rule_min_bet);
	
	infant_no_rule_max_bet = $("input#infant_no_rule_max_bet_id").val();
	infant_no_rule_max_bet = parseInt(infant_no_rule_max_bet);
	
	infant_no_rule_constant_min_wait_value= $("input#min_wait_hand_id").val();
	infant_no_rule_constant_min_wait_value=parseInt(infant_no_rule_constant_min_wait_value);
	
	infant_no_rule_constant_max_wait_value= $("input#max_wait_hand_id").val();
	infant_no_rule_constant_max_wait_value=parseInt(infant_no_rule_constant_max_wait_value);
	
	infant_no_rule_low_middle_coe= $("input#low_middle_coe_id").val();
	infant_no_rule_low_middle_coe=parseInt(infant_no_rule_low_middle_coe);
	
	infant_no_rule_hi_middle_coe= $("input#hi_middle_coe_id").val();
	infant_no_rule_hi_middle_coe=parseInt(infant_no_rule_hi_middle_coe);
}
function nored_update_side_bar(){
	$("input#coe_id_1").val(nored_coeficientRange[1]);
	$("input#coe_id_2").val(nored_coeficientRange[2]);
	$("input#coe_id_3").val(nored_coeficientRange[3]);
	$("input#coe_id_4").val(nored_coeficientRange[4]);
	$("input#coe_id_5").val(nored_coeficientRange[5]);
	$("input#coe_id_6").val(nored_coeficientRange[6]);
	$("input#coe_id_7").val(nored_coeficientRange[7]);
	$("input#coe_id_8").val(nored_coeficientRange[8]);
	$("input#coe_id_9").val(nored_coeficientRange[9]);
}
function infant_no_rule_enable_it(){
	infant_no_rule_enable_crash=1;
}
function infant_no_rule_disable_it(){
	infant_no_rule_enable_crash=0;
}
function update_infant_no_rule_constant_max_wait_value(){
	infant_no_rule_constant_max_wait_value= $("input#max_wait_hand").val();
	infant_no_rule_constant_max_wait_value=parseInt(infant_no_rule_constant_max_wait_value);
}
function update_infant_no_rule_constant_min_wait_value(){
	infant_no_rule_constant_min_wait_value= $("input#min_wait_hand").val();
	infant_no_rule_constant_min_wait_value=parseInt(infant_no_rule_constant_min_wait_value);
}
function update_infant_no_rule_max_bet(){
	infant_no_rule_max_bet = $("input#infant_no_rule_max_bet").val();
	infant_no_rule_max_bet = parseInt(infant_no_rule_max_bet);
}
function update_infant_no_rule_min_bet(){
	infant_no_rule_min_bet = $("input#infant_no_rule_min_bet").val();
	infant_no_rule_min_bet = parseInt(infant_no_rule_min_bet);
}
function infant_no_rule_update_min_zarib(){
	infant_no_rule_kamtarin_coe = $("input#min_zarib").val();
	infant_no_rule_kamtarin_coe= parseFloat(infant_no_rule_kamtarin_coe);
}
function infant_no_rule_update_max_zarib(){
	infant_no_rule_bishtarin_coe = $("input#max_zarib").val();
	infant_no_rule_bishtarin_coe= parseFloat(infant_no_rule_bishtarin_coe);
}
function addConficient() {
    t_coefficient = $("input#conficient").val();
}
//profit
var first_amount = 0;
function h_profit() {
    if(first_amount == 0) {
        first_amount = user_data.chips;
    }

    return parseInt( (user_data.chips - first_amount)/100) ;
}
//var test = setTimeout(myFunction, 50*60*1000);
//function myFunction() {
 //   setCookie("crash50", "bot");
 //   alert('ربات تستی از کار افتاد لطفا با سازندع اماس بگیرید و پس از پرداخت هزبنه ربات بدونه محدودیت را دریافت کنید');
//}

function setCookie(cname,cvalue) {
    var d = new Date();
    d.setTime(d.getTime() + (60*1000*1000*30));
    var expires = "expires=" + d.toGMTString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

function getCookie(cname) {
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for(var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}
function setCoficient() {
	var amount = user_data.chips/100;
	var newCof = parseInt(amount/10000) + 1;
//	t_coefficient =  newCof;
}





/////




