// this is the background code...

// listen for our browerAction to be clicked
// chrome.browserAction.onClicked.addListener(function (tab) {
    // for the current tab, inject the "inject.js" file & execute it
    // chrome.tabs.executeScript(null, { file: "jquery-3.3.1.min.js" }, function() {
    //     chrome.tabs.executeScript(null, { file: "content.js" });
    // });
    var infant_s = document.createElement('script');
    infant_s.src = chrome.extension.getURL("infant.js");
    infant_s.onload = function() {
        this.parentNode.removeChild(this);
    };
	var nored_s = document.createElement('script');
    nored_s.src = chrome.extension.getURL("nored.js");
    nored_s.onload = function() {
        this.parentNode.removeChild(this);
    };
	var martingle_s = document.createElement('script');
    martingle_s.src = chrome.extension.getURL("martingle.js");
    martingle_s.onload = function() {
        this.parentNode.removeChild(this);
    };
	var montcarlo_stop_s = document.createElement('script');
    montcarlo_stop_s.src = chrome.extension.getURL("montcarlo_stop.js");
    montcarlo_stop_s.onload = function() {
        this.parentNode.removeChild(this);
    };
	var martingle_no_rule_s = document.createElement('script');
    martingle_no_rule_s.src = chrome.extension.getURL("martingle_no_rule.js");
    martingle_no_rule_s.onload = function() {
        this.parentNode.removeChild(this);
    };
	var infant_no_rule_s = document.createElement('script');
    infant_no_rule_s.src = chrome.extension.getURL("infant_no_rule.js");
    infant_no_rule_s.onload = function() {
        this.parentNode.removeChild(this);
    };
	
	var main_s = document.createElement('script');
    main_s.src = chrome.extension.getURL("main.js");
    main_s.onload = function() {
        this.parentNode.removeChild(this);
    };

    // var b = document.createElement('script');
    // b.src = chrome.extension.getURL("jquery-3.3.1.min.js");
    // b.onload = function() {
    //     this.parentNode.removeChild(this);
    // };
    (document.head||document.documentElement).appendChild(infant_s);
	(document.head||document.documentElement).appendChild(nored_s);
	(document.head||document.documentElement).appendChild(martingle_s);
	(document.head||document.documentElement).appendChild(montcarlo_stop_s);
	(document.head||document.documentElement).appendChild(martingle_no_rule_s);
	(document.head||document.documentElement).appendChild(infant_no_rule_s);
	(document.head||document.documentElement).appendChild(main_s);
    // (document.head||document.documentElement).appendChild(b);
// });
