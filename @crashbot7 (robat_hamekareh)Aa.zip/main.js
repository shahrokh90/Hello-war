﻿var t_coefficient=1;
var main_f_game_waiting = game_waiting;
var h_information = $('div.user-name');
h_information.after("<div class='top-link'><h4 id='hadi-box'><b> ربات فعال گرديد@enfejarbot_7 .</b></h4></div> ");
function enable_infant(){
	infant_enable_crash=1;
	nored_enable_crash=0;
	martingle_enable_crash=0;
	montcarlo_stop_enable_crash=0;
	martingle_no_rule_enable_crash=0;
	infant_no_rule_enable_crash=0;
}
function enable_nored(){
	infant_enable_crash=0;
	nored_enable_crash=1;
	martingle_enable_crash=0;
	montcarlo_stop_enable_crash=0;
	martingle_no_rule_enable_crash=0;
	infant_no_rule_enable_crash=0;
}
function enable_martingle(){
	infant_enable_crash=0;
	nored_enable_crash=0;
	martingle_enable_crash=1;
	montcarlo_stop_enable_crash=0;
	martingle_no_rule_enable_crash=0;
	infant_no_rule_enable_crash=0;
}
function enable_montcarlo_stop(){
	infant_enable_crash=0;
	nored_enable_crash=0;
	martingle_enable_crash=0;
	montcarlo_stop_enable_crash=1;
	martingle_no_rule_enable_crash=0;
	infant_no_rule_enable_crash=0;
}
function enable_martingle_no_rule(){
	infant_enable_crash=0;
	nored_enable_crash=0;
	martingle_enable_crash=0;
	montcarlo_stop_enable_crash=0;
	martingle_no_rule_enable_crash=1;
	infant_no_rule_enable_crash=0;
}
function enable_infant_no_rule(){
	infant_enable_crash=0;
	nored_enable_crash=0;
	martingle_enable_crash=0;
	montcarlo_stop_enable_crash=0;
	martingle_no_rule_enable_crash=0;
	infant_no_rule_enable_crash=1;
}
function main_option() {
	var h_option_text='<input id="conficient" class="main_amir" type="number" onchange="main_addConficient()" placeholder="صریب بازی" value="' + t_coefficient + '">';
	
    h_option_text += '<button class="infant_amir" onclick="infant_it()">  تشخيص ضريب قرمز بعد باخت  </button>';
	
	h_option_text += '<button class="nored_amir" onclick="nored_it()">  ضريب متغيير و متوالي  </button>';
	
	h_option_text += '<button class="martingle_amir" onclick="martingle_it()">  فيبوناچي - مارتينگل  </button>';
	
	h_option_text += '<button class="montkarlo_amir" onclick="montcarlo_stop_it()">  توقف مونت كارلو  </button>';
	h_option_text += '<button class="martingle_no_rule_amir" onclick="martingle_no_rule_it()">مارتينگل بی قانون</button>';
	h_option_text += '<button class="infant_no_rule_amir" onclick="infant_no_rule_it()">تشخيص ضريب فرمز بی قانون</button>';
	h_option_text += '<button class="openav" onclick="openNav()">  منوي تغيير ضرايب  </button>';
	
	$('input.main_amir').remove();
	$('button.infant_amir').remove();
	$('button.nored_amir').remove();
	$('button.martingle_amir').remove();
	$('button.montkarlo_amir').remove();
	$('button.martingle_no_rule_amir').remove();
	$('button.infant_no_rule_amir').remove();
	$('button.openav').remove();
    $('div.top-bar').prepend(h_option_text);
}
function main_addConficient(){
	t_coefficient = $("input#conficient").val();
}
function infant_it(){
	remove_element_by_id("mySidenav");
		if(infant_enable_crash===1){
			infant_enable_crash=0;
			set_display_algorithm("غير فعال است");
		}else{
			enable_infant();
			set_display_algorithm("تشخيص ضريب قرمز بعد باخت");
			infant_add_side_bar();
		}
}
function nored_it(){
	remove_element_by_id("mySidenav");
		if(nored_enable_crash===1){
			nored_enable_crash=0;
			set_display_algorithm("غير فعال است");
		}else{
			enable_nored();
			set_display_algorithm("ضريب متغيير و متوالي");
			nored_add_side_bar();
		}
}
function martingle_it(){
	remove_element_by_id("mySidenav");
		if(martingle_enable_crash===1){
			martingle_enable_crash=0;
			set_display_algorithm("غير فعال است");			
		}else{
			enable_martingle();
			set_display_algorithm("فيبوناچي - مارتينگل");
			martingle_add_side_bar();
		}
}
function montcarlo_stop_it(){
	remove_element_by_id("mySidenav");
		if(montcarlo_stop_enable_crash===1){
			montcarlo_stop_enable_crash=0;
			set_display_algorithm("غير فعال است");			
		}else{
			enable_montcarlo_stop();
			set_display_algorithm("توقف مونت كارلو");
			montcarlo_stop_add_side_bar();
		}
}
function martingle_no_rule_it(){
	remove_element_by_id("mySidenav");
		if(martingle_no_rule_enable_crash===1){
			martingle_no_rule_enable_crash=0;
			set_display_algorithm("غير فعال است");			
		}else{
			enable_martingle_no_rule();
			set_display_algorithm("مارتينگل بی قانون");
			martingle_no_rule_add_side_bar();
		}
}
function infant_no_rule_it(){
	remove_element_by_id("mySidenav");
		if(infant_no_rule_enable_crash===1){
			infant_no_rule_enable_crash=0;
			set_display_algorithm("غير فعال است");			
		}else{
			enable_infant_no_rule();
			set_display_algorithm("تشخيص ضريب فرمز بی قانون");
			infant_no_rule_add_side_bar();
		}
}
game_waiting = (function () {
    return function (str) {
		main_option();
        main_f_game_waiting.apply(this, arguments); // calling the real function       
    };
}());
function remove_element_by_id(elmnt_id){
	if(document.getElementById(elmnt_id)){
		var elmnt = document.getElementById(elmnt_id);
		elmnt.parentNode.removeChild(elmnt);
	}
}
function openNav() {
	if(document.getElementById("mySidenav")){
		document.getElementById("mySidenav").style.width = "250px";
	}
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
function set_display_algorithm(algo){
	if(document.querySelectorAll('#hadi-box > b:nth-child(6)')[0]){
		document.querySelectorAll('#hadi-box > b:nth-child(6)')[0].innerText=algo;
	}
	if(document.querySelectorAll('#hadi-box > b:nth-child(6)')[1]){
		document.querySelectorAll('#hadi-box > b:nth-child(6)')[1].innerText=algo;
	}
}
var pie_click=0;
var con_click=0;
function t_recon(){
//reconnect
var con_btn=document.querySelector('#disconnect_screen > table > tbody > tr > td > center > a');
var pie_btn=document.querySelector('#play_button');
var discon_disp=document.querySelector('#disconnect_screen');
var discon_disp_text=discon_disp.getAttribute("style");
var lobby_disp=document.querySelector('#lobby_screen');
var lobby_disp_text=lobby_disp.getAttribute("style");
if(lobby_disp_text==="display: block;" && discon_disp_text==="display: none;" && pie_click<3){
	pie_btn.click();
	pie_click++;
}else if(lobby_disp_text==="display: none;" && discon_disp_text==="display: block;" && con_click<3){
	con_btn.click();
	con_click++;
}else if(lobby_disp_text==="display: none;" && discon_disp_text==="display: none;"){
	con_click=0;
	pie_click=0;
}else if(lobby_disp_text==="display: block;" && discon_disp_text==="display: block;"){
	console.log("unusual condition of disp disp");
}else{
	document.querySelector('#reload-button').click();
}
}
setInterval(t_recon,2000);
