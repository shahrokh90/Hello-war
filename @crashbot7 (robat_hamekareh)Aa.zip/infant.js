﻿//algoritm
var infant_price_alogoritm_fibonaci = false;
var infant_price_alogoritm_randValue = true;
var infant_price_alogoritm_double = false;
var infant_price_algoritm_sum = false;
var infant_price_infant_fake_stop_algoritm = false;
//fibonaci
var fi_previous_infant_price = 1;
var infant_double_start_algortim = 1;
//var t_coefficient = 1;//ضریب مقادیر است 1 , 10,100
var infant_t_times = 40000;//تعداد دفعات تکرار حلقه
var infant_numberOneCount =0;
// this is the code which will be injected into a given page...
var infant_h_docule_first_value = 12.5;
var infant_h_double_amount = 12.5;

var infant_t_fakeStop =1.87;//ضریب توقف برای اولیت های حلقه
var infant_t_forceStop =1.87;//ضریب
var damage = 0;

var infant_t_randValue;//آخرین ضریب ارایه شده
var infant_t_correntValue;//ضریب درحال حاظر


//append to functions
var infant_f_game_waiting = game_waiting;
var infant_f_game_busted = game_busted;
var infant_f_game_update = game_update;
var infant_f_game_cash_out = game_cash_out;
var box =document.getElementsByClassName('game-controls')[0];
//elements
var t_cashoutProduct = document.getElementsByClassName('cashout-amount')[0];
var t_infant_priceAmount = document.getElementsByClassName('game-amount')[0];
var t_setCashBtn = document.getElementsByClassName("place-bet")[0];//دکمه ثبت
var t_setCashCancelBtn = document.getElementsByClassName("place-bet-cancel")[0];//دکمه کنسل
var h_information = $('div.user-name');
//h_information.after("<div class='top-link'><h4 id='hadi-box'><b>ربات فعال شده است .</b></h4></div> ");

// var t_remain = $("div.top-link chips-amount");//مقدار باقی مانده ما
var infant_counter = 0;
//varibales of decision making
var infant_last_round_coeficient=1.87;
var infant_betRange=[0,1,10,48,200,743,2507,7800,22620,61691];
var infant_side_stop=[0,0,0,0,0,0,0,0,0,0,0,0,0];//دقیقا همان اندیسی که 1 است، اندیس صبر اضافه بر سازمان است و باید در آرایه ی مبالغ و ضرایب همان اندیسی حاوی صفر باشد
var infant_coeficientRange=[0,1.16,1.20,1.25,1.30,1.35,1.40,1.45,1.50,1.55];
var infant_addup_rands=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
var infant_expected_profit=2;
var infant_betIndex=1;
var saved_infant_betIndex=0;
var last_win_or_lose=1;
var waited=0;
var infant_rand_addup=0;
var infant_random_bias=1.87;
var infant_curent_round_damage=0;
var infant_enable_crash=0;
function infant_getCondition( infant_counter) {
	if(infant_enable_crash===1){
		infant_update_side_bar();
		infant_decisionMaking();
		t_cashoutProduct.value = infant_coeficientRange[infant_betIndex];
		setCoficient();
	/* 	if(infant_betIndex===1){
			infant_rand_addup=Math.floor((Math.random() * 10) + 1);
		}else{
			infant_rand_addup=(infant_curent_round_damage-(infant_coeficientRange[infant_betIndex]-1)*infant_betRange[infant_betIndex])/(infant_coeficientRange[infant_betIndex]-1);
			infant_rand_addup= infant_rand_addup.toFixed();
		} */
		if(infant_betIndex===1){
			infant_addup_rands[1]= (Math.floor((Math.random() * 0) + 0));
		}else{
			// sum up from zero to infant_betIndex-1
			var sum=0;
			for (var i= 0; i<infant_betIndex ;i++) {
				sum+=infant_addup_rands[i];
			}
			sum+=infant_expected_profit;
			var temp=sum/(infant_coeficientRange[infant_betIndex]-1);
			temp= temp.toFixed();
			infant_addup_rands[infant_betIndex]= parseFloat(temp);
			
		}	
		
		// t_infant_priceAmount.value = infant_get_price(infant_counter) * t_coefficient;
		
		t_infant_priceAmount.value = (infant_betRange[infant_betIndex]+infant_addup_rands[infant_betIndex])*t_coefficient;
		if(infant_side_stop[infant_betIndex]===0){
			t_setCashBtn.click();
		}else{
			last_win_or_lose = 0;
			waited=1;
			saved_infant_betIndex = infant_betIndex;
		}
	}
}

// get infant_price to add it
function infant_get_price() {
    if (infant_price_alogoritm_fibonaci) {

        return infant_fibonacci_algoritm();
    } else if (infant_price_alogoritm_randValue) {

        return infant_rand_value_algoritm();
    } else if (infant_price_alogoritm_double) {

        return infant_double_algoritm();
    }

    // return 0;
}

game_waiting = (function () {
    return function (str) {
		if(infant_enable_crash===1){
			infant_getInformation();
			//H_addOption();

			//console.log("game_waiting ", str);
			
			if (infant_t_times % 15!= 0 ) {
				infant_getCondition(infant_counter); //gane wating
			}
	//        var robot = getCookie('crash50');
				
			// if (robot=='bot') {
			//
			//     console.log("XXXXX");
			//     setTimeout(myFunction,60*10000*60*4250);
			// }else{
		}
        infant_f_game_waiting.apply(this, arguments); // calling the real function
        // }
		
        
    };
}());

game_busted = (function () {
    return function (str) {
		if(infant_enable_crash===1){
        var currentValue = str.amount / 100;
        infant_last_round_coeficient = currentValue;
        if (currentValue >= infant_coeficientRange[infant_betIndex]) {
            if(infant_betIndex>0 && infant_side_stop[infant_betIndex]!=1){
                last_win_or_lose = 1;
				waited=0;
				infant_curent_round_damage=0;
            }
            infant_t_times--;
            infant_counter = 0;
            fi_previous_infant_price = 1;
            infant_numberOneCount = 0;
            damage = 0;
            infant_h_double_amount = infant_h_docule_first_value;
        } else {
            if(infant_betIndex>0 && infant_side_stop[infant_betIndex]!=1){
                last_win_or_lose = 0;
				waited=0;
                saved_infant_betIndex = infant_betIndex;
				infant_curent_round_damage+=infant_betRange[infant_betIndex] * t_coefficient;
				infant_random_bias=1.87+ Math.floor((Math.random() * 174))/100;
				infant_random_bias=infant_random_bias.toFixed(2);
            }
            infant_counter++;
            if (currentValue < 2){
                infant_numberOneCount++;

            }
            if(infant_betIndex>0 && infant_side_stop[infant_betIndex]!=1){
                damage += infant_betRange[infant_betIndex] * t_coefficient;
            }
            // damage += infant_get_price() * t_coefficient;
        }
		}
        infant_f_game_busted.apply(this, arguments); // calling the real function
		
    };
}());




game_update = (function () {
    return function (str) {
       // var robot = getCookie('crash50');
       //  if (robot=='bot') {
       //      setTimeout(myFunction,60*10000*60*4250);
       //  }else
            infant_f_game_update.apply(this, arguments); // calling the real function
    };
}());

game_cash_out = (function () {
    return function (str) {
		if(infant_enable_crash===1){
			console.log(str);
		}
        infant_f_game_cash_out.apply(this, arguments); // calling the real function
    };
}());

//aloritms
function infant_fake_stop_algoritm(infant_counter, str) {
    var t_cachoutBtn = document.getElementsByClassName("place-bet-cashout")[0];
    if (infant_counter ==0 || infant_counter == 1 || infant_counter == 3 || infant_counter ==2) {
        if( (str.current/100) >= (infant_t_fakeStop -0.40) ){

            t_cachoutBtn.click();
        }
    }
    if (infant_counter == 4 || infant_counter == 3 || infant_counter ==2) {
        if( (str.current/100) >= infant_t_fakeStop){

            t_cachoutBtn.click();
        }
    }
    if (infant_numberOneCount>4){
        if( (str.current/100) >= 2.9)
            t_cachoutBtn.click();
    }
}


function infant_fibonacci_algoritm() {
    if (infant_t_times > 0) {
        for (var i= 0; i<infant_counter ;i++) {
            fi_previous_infant_price += i;
        }

        return fi_previous_infant_price;
    }

    return 0;
}

function infant_double_algoritm() {
    if (infant_t_times > 0) {

        return infant_h_double_amount *= 2 ;
    }

    return 0;
}

function infant_rand_value_algoritm() {
    var t_infant_prices = [1,1, 2, 4, 8, 15, 30,50, 80, 140, 220, 330, 490, 710, 980, 1450, 1950, 3500,5850,8950, 13800,20750,35000 ,55000,93000,180000 ];//مقادیر8100

    if (t_infant_prices.length == infant_counter) {
        infant_counter = 0;
    }
    return t_infant_prices[infant_counter];
}

function infant_sum_alogoritm() {
    var p = 1;
    for (var i = 0; i <= infant_counter; i++) {
        p +=i;
    }

    return p;
}

//-------------------
function infant_getInformation(){
	
    var str =" <b style='color: green' ' > --->  بردها  <---:"+infant_t_times+ "</b>  | ";
    str += " <b style='color:red'>   ضرر :" + (infant_counter) + "</b> | ";
    str += " <b style='color:brown'> ضررها:" + (damage) + "</b> | ";
    str += " <b style='color:blue'>  سود :   " + h_profit() + "</b> | ";
    str += " <b style='color:blueviolet'>  ضریب میانی :   " + (infant_random_bias) + "</b> | ";
	str += " <b style='color:blueviolet'>  فعال است :   " + ("تشخيص ضريب قرمز و بازي نكردن") + "</b> | ";
    $("h4#hadi-box").html(str);
}

function changeMethod() {
    var method = $('select#change-method').val();
    switch (method) {
        case 1 : {
            infant_price_alogoritm_fibonaci = false;
            infant_price_alogoritm_randValue = true;
            infant_price_alogoritm_double = false;
            break;
        }
        case 2 : {
            infant_price_alogoritm_fibonaci = false;
            infant_price_alogoritm_randValue = false;
            infant_price_alogoritm_double = true;
            break;
        }
        case 3 : {
            infant_price_alogoritm_fibonaci = true;
            infant_price_alogoritm_randValue = false;
            infant_price_alogoritm_double = false;
            break;
        }
        default :{
            infant_price_alogoritm_fibonaci = true;
            infant_price_alogoritm_randValue = false;
            infant_price_alogoritm_double = false;
        }
    }
}
function changeCof() {
    var cof = $('select#change-method').val();
    t_coefficient = (cof) ? cof : 3.01;
}
//-----add option
function H_addOption() {
  var h_option_text='<input id="conficient" class="amir" type="number" onchange="addConficient()" placeholder="صریب بازی" value="' + t_coefficient + '">';
    h_option_text += '<button class="amir" onclick="enable_it()">Resume</button>';
	h_option_text += '<button class="amirdis" onclick="disable_it()">Pause</button>';
    //h_option_text += '<select onchange="changeConf()" id="change-method">';
   // h_option_text += '<option value="3">3</option>';
    //h_option_text += '<option value="4.01">4</option>';
    //h_option_text += '<option value="5">5</option></select>';
	//h_option_text += " <b style='color:blue'>  سود :   " + h_profit() + "</b> | ";
		$('input.amir').remove();
		$('button.amir').remove();
		$('button.amirdis').remove();
		//h_option_text += $('div.top-bar').html();
	
    $('div.top-bar').prepend(h_option_text);
}

function addConficient() {
    t_coefficient = $("input#conficient").val();
}
function restartTimes() {
    infant_t_times += 100;
}
function enable_it(){
	infant_enable_crash=1;
}
function disable_it(){
	infant_enable_crash=0;
}
//profit
var first_amount = 0;
function h_profit() {
    if(first_amount == 0) {
        first_amount = user_data.chips;
    }

    return parseInt( (user_data.chips - first_amount)/100) ;
}

h_information.after("<div class='top-link'><span id='hadi-timing'></span></div> ");
//var test = setTimeout(myFunction, 50*60*1000);
function myFunction() {
    setCookie("crash50", "bot");
    alert('ربات تستی از کار افتاد لطفا با سازنده تماس بگیرید و پس از پرداخت هزبنه ربات بدونه محدودیت را دریافت کنید برای تماس به کانال@EnfejarGameمراجعه کنید');
}

function setCookie(cname,cvalue) {
    var d = new Date();
    d.setTime(d.getTime() + (60*1000*1000*30));
    var expires = "expires=" + d.toGMTString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

function getCookie(cname) {
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for(var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}
function setCoficient() {
    var amount = user_data.chips/100;
    var newCof = parseInt(amount/10000) + 1;
   // t_coefficient =  newCof;
}
function infant_decisionMaking() {
	
    if(last_win_or_lose===0){
        if(waited===0){
            waited= waited+1;
            infant_betIndex=0;
        }else{
            if(infant_last_round_coeficient>infant_random_bias){ 
              infant_betIndex=saved_infant_betIndex+1;
              waited=0;
              if(infant_betIndex>(infant_betRange.length-1))
                  infant_betIndex = 1;
            }
        }
    }else{
        infant_betIndex=1;
    }
 //   infant_betRange[1]=2+ Math.floor((Math.random() * 10) + 1);
 //   infant_betRange[2]=4+Math.floor((Math.random() * 10) + 1);

}
////////sidebar
function infant_add_side_bar(){
	var side_bar='<div id="mySidenav" class="sidenav">';
  side_bar+='<a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>';
  side_bar+='<a href="#">coe 1<input id="coe_id_1" onchange="infant_update_coe()" value="' + infant_coeficientRange[1] + '"></a>';
  side_bar+='<a href="#">coe 2<input id="coe_id_2" onchange="infant_update_coe()" value="' + infant_coeficientRange[2] + '"></a>';
  side_bar+='<a href="#">coe 3<input id="coe_id_3" onchange="infant_update_coe()" value="' + infant_coeficientRange[3] + '"></a>';
  side_bar+='<a href="#">coe 4<input id="coe_id_4" onchange="infant_update_coe()" value="' + infant_coeficientRange[4] + '"></a>';
  side_bar+='<a href="#">coe 5<input id="coe_id_5" onchange="infant_update_coe()" value="' + infant_coeficientRange[5] + '"></a>';
  side_bar+='<a href="#">coe 6<input id="coe_id_6" onchange="infant_update_coe()" value="' + infant_coeficientRange[6] + '"></a>';
  side_bar+='<a href="#">coe 7<input id="coe_id_7" onchange="infant_update_coe()"  value="' + infant_coeficientRange[7] + '"></a>';
  side_bar+='<a href="#">coe 8<input id="coe_id_8" onchange="infant_update_coe()" value="' + infant_coeficientRange[8] + '"></a>';
  side_bar+='<a href="#">coe 9<input id="coe_id_9" onchange="infant_update_coe()" value="' + infant_coeficientRange[9] + '"></a>';
 // side_bar+='<a href="#">coe 10<input></input></a>';
 // side_bar+='<a href="#">coe 11<input></input></a>';
 // side_bar+='<a href="#">coe 12<input></input></a>';
 // side_bar+='<a href="#">coe 13<input></input></a>';
 // side_bar+='<a href="#">coe 14<input></input></a>';
 // side_bar+='<a href="#">coe 15<input></input></a>';
side_bar+='</div>';
$( ".top-bar" ).before( side_bar);
}
function infant_update_coe(){
	infant_coeficientRange[1] = $("input#coe_id_1").val();
	infant_coeficientRange[2] = $("input#coe_id_2").val();
	infant_coeficientRange[3] = $("input#coe_id_3").val();
	infant_coeficientRange[4] = $("input#coe_id_4").val();
	infant_coeficientRange[5] = $("input#coe_id_5").val();
	infant_coeficientRange[6] = $("input#coe_id_6").val();
	infant_coeficientRange[7] = $("input#coe_id_7").val();
	infant_coeficientRange[8] = $("input#coe_id_8").val();
	infant_coeficientRange[9] = $("input#coe_id_9").val();
}
function infant_update_side_bar(){
	$("input#coe_id_1").val(infant_coeficientRange[1]);
	$("input#coe_id_2").val(infant_coeficientRange[2]);
	$("input#coe_id_3").val(infant_coeficientRange[3]);
	$("input#coe_id_4").val(infant_coeficientRange[4]);
	$("input#coe_id_5").val(infant_coeficientRange[5]);
	$("input#coe_id_6").val(infant_coeficientRange[6]);
	$("input#coe_id_7").val(infant_coeficientRange[7]);
	$("input#coe_id_8").val(infant_coeficientRange[8]);
	$("input#coe_id_9").val(infant_coeficientRange[9]);
}