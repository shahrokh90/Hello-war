﻿//algoritm
var montcarlo_stop_price_alogoritm_fibonaci = false;
var montcarlo_stop_price_alogoritm_randValue = true;
var montcarlo_stop_price_alogoritm_double = false;
var montcarlo_stop_price_algoritm_sum = false;
var montcarlo_stop_price_montcarlo_stop_fake_stop_algoritm = false;
//fibonaci
var montcarlo_stop_fi_previous_price = 1;
var montcarlo_stop_double_start_algortim = 1;
//var t_coefficient = 1;//ضریب مقادیر است 1 , 10,100
var montcarlo_stop_t_times = 10000;//تعداد دفعات تکرار حلقه
var montcarlo_stop_numberOneCount =0;
// this is the code which will be injected into a given page...
var montcarlo_stop_h_docule_first_value = 12.5;
var montcarlo_stop_h_double_amount = 12.5;

var montcarlo_stop_t_fakeStop = 2.80;//ضریب توقف برای اولیت های حلقه
var montcarlo_stop_t_forceStop = 3.48;//ضریب
var damage = 0;

var montcarlo_stop_t_randValue;//آخرین ضریب ارایه شده
var montcarlo_stop_t_correntValue;//ضریب درحال حاظر


//append to functions
var montcarlo_stop_f_game_waiting = game_waiting;
var montcarlo_stop_f_game_busted = game_busted;
var montcarlo_stop_f_game_update = game_update;
var montcarlo_stop_f_game_cash_out = game_cash_out;
var box =document.getElementsByClassName('game-controls')[0];
//elements
var t_cashoutProduct = document.getElementsByClassName('cashout-amount')[0];
var t_montcarlo_stop_priceAmount = document.getElementsByClassName('game-amount')[0];
var t_setCashBtn = document.getElementsByClassName("place-bet")[0];//دکمه ثبت
var t_setCashCancelBtn = document.getElementsByClassName("place-bet-cancel")[0];//دکمه کنسل
var h_information = $('div.user-name');
//h_information.after("<div class='top-link'><h4 id='hadi-box'><b>ربات فعال شده است  .</b></h4></div> ");

// var t_remain = $("div.top-link chips-amount");//مقدار باقی مانده ما
var montcarlo_stop_counter = 0;
//modification
var montcarlo_stop_BETs=[1,4,12,0,36,108,0,324,810,0,1851,3934,0,7869,14950,27182,0,47569,80502];
var montcarlo_stop_COEs=[1.5,1.5,1.5,0,1.5,1.5,0,1.5,1.6,0,1.7,1.8,0,1.9,2,2.1,0,2.2,2.3];
var montcarlo_stop_t_bias=2.8;
var montcarlo_stop_betIndex=0;
var montcarlo_stop_allow_play=1;
var montcarlo_stop_enable_crash=0;
function montcarlo_stop_getCondition( montcarlo_stop_counter) {
    t_cashoutProduct.value = montcarlo_stop_COEs[montcarlo_stop_betIndex];
    //montcarlo_stop_setCoficient();
    t_montcarlo_stop_priceAmount.value = montcarlo_stop_BETs[montcarlo_stop_betIndex] * t_coefficient;
    t_setCashBtn.click();
}
game_waiting = (function () {
    return function (str) {
		// H_addOption();
		if(	montcarlo_stop_enable_crash===1){
        //console.log("game_waiting ", str);
        montcarlo_stop_getInformation();
        //if (montcarlo_stop_t_times % 15!= 0 ) {
           montcarlo_stop_getCondition(montcarlo_stop_counter); //gane wating
        //}
        //var robot = getCookie('crash50');
            
        //if (robot=='bot') {

            console.log("XXXXX");
            //setTimeout(myFunction,60*10000*60*4250);
        //}else{
		}
        montcarlo_stop_f_game_waiting.apply(this, arguments); // calling the real function
        //	}
        
    };
}());

game_busted = (function () {
    return function (str) {
		if(	montcarlo_stop_enable_crash===1){
        var currentValue = str.amount / 100;
        if (currentValue >= montcarlo_stop_COEs[montcarlo_stop_betIndex] && montcarlo_stop_COEs[montcarlo_stop_betIndex]!=0) {
            montcarlo_stop_t_times--;
            montcarlo_stop_counter = 0;
            montcarlo_stop_fi_previous_price = 1;
            montcarlo_stop_numberOneCount = 0;
            damage = 0;
            montcarlo_stop_h_double_amount = montcarlo_stop_h_docule_first_value;
			if(montcarlo_stop_COEs[montcarlo_stop_betIndex]===0){
				montcarlo_stop_allow_play=0;
			}
			if(montcarlo_stop_allow_play===1){
				montcarlo_stop_betIndex=0;
			}
        } else if(montcarlo_stop_COEs[montcarlo_stop_betIndex]!=0) {
            montcarlo_stop_counter++;
            if (currentValue < 2){
                montcarlo_stop_numberOneCount++;
            }
			if(montcarlo_stop_COEs[montcarlo_stop_betIndex]===0){
				montcarlo_stop_allow_play=0;
			}
			if(montcarlo_stop_allow_play===1){
				montcarlo_stop_betIndex++;
			}
            damage += montcarlo_stop_BETs[montcarlo_stop_betIndex] * t_coefficient;
        }else{
			montcarlo_stop_allow_play=0;
		}
		if(montcarlo_stop_allow_play===0 && currentValue>montcarlo_stop_t_bias){
				montcarlo_stop_allow_play=1;
				montcarlo_stop_betIndex++;
		}
		}
        montcarlo_stop_f_game_busted.apply(this, arguments); // calling the real function
    };
}());




game_update = (function () {
    return function (str) {
       //var robot = getCookie('crash50');
     ///   if (robot=='bot') {
           // setTimeout(myFunction,60*10000*60*4250);
      //  }else
            montcarlo_stop_f_game_update.apply(this, arguments); // calling the real function
    };
}());

game_cash_out = (function () {
    return function (str) {
        console.log(str);
        montcarlo_stop_f_game_cash_out.apply(this, arguments); // calling the real function
    };
}());

//aloritms
function montcarlo_stop_fake_stop_algoritm(montcarlo_stop_counter, str) {
    var t_cachoutBtn = document.getElementsByClassName("place-bet-cashout")[0];
    if (montcarlo_stop_counter ==0 || montcarlo_stop_counter == 1 || montcarlo_stop_counter == 3 || montcarlo_stop_counter ==2) {
        if( (str.current/100) >= (montcarlo_stop_t_fakeStop -0.40) ){

            t_cachoutBtn.click();
        }
    }
    if (montcarlo_stop_counter == 4 || montcarlo_stop_counter == 3 || montcarlo_stop_counter ==2) {
        if( (str.current/100) >= montcarlo_stop_t_fakeStop){

            t_cachoutBtn.click();
        }
    }
    if (montcarlo_stop_numberOneCount>5){
        if( (str.current/100) >= 2.9)
            t_cachoutBtn.click();
    }
}


function montcarlo_stop_fibonacci_algoritm() {
    if (montcarlo_stop_t_times > 0) {
        for (var i= 0; i<montcarlo_stop_counter ;i++) {
            montcarlo_stop_fi_previous_price += i;
        }

        return montcarlo_stop_fi_previous_price;
    }

    return 0;
}

function montcarlo_stop_double_algoritm() {
    if (montcarlo_stop_t_times > 0) {

        return montcarlo_stop_h_double_amount *= 2 ;
    }

    return 0;
}

function montcarlo_stop_rand_value_algoritm() {
	
    var t_montcarlo_stop_prices = [1,1,2,3,4,6,9,12,18,25,35,50,70,98,138,194,273,383,538,755,1059,1487,2086,2928,4108,5765,8090,11353,15930,22354,31368,44017,61766,86672,121620];//مقادیر8100

    if (t_montcarlo_stop_prices.length == montcarlo_stop_counter) {
        montcarlo_stop_counter = 0;
    }
    return t_montcarlo_stop_prices[montcarlo_stop_counter];
}

function montcarlo_stop_sum_alogoritm() {
    var p = 1;
    for (var i = 0; i <= montcarlo_stop_counter; i++) {
        p +=i;
    }

    return p;
}

//-------------------
function montcarlo_stop_getInformation(){
    var str =" <b style='color: green' ' >--> بردها <--  :"+montcarlo_stop_t_times+ "</b>  | ";
    str += " <b style='color:red'>  ضرر :" + (montcarlo_stop_counter) + "</b> | ";
    str += " <b style='color:brown'>   ضررها :" + (damage) + "</b> | ";
    str += " <b style='color:blue'>  سود :   " + h_profit() + "</b> | ";
    str += " <b style='color:blueviolet'>میانی :   " + (montcarlo_stop_t_fakeStop) + "</b> | ";
	str += " <b style='color:blueviolet'>  فعال است :   " + ("توقف مونت كارلو ") + "</b> | ";
    $("h4#hadi-box").html(str);
}

function montcarlo_stop_changeMethod() {
    var method = $('select#change-method').val();
    switch (method) {
        case 1 : {
            montcarlo_stop_price_alogoritm_fibonaci = false;
            montcarlo_stop_price_alogoritm_randValue = true;
            montcarlo_stop_price_alogoritm_double = false;
            break;
        }
        case 2 : {
            montcarlo_stop_price_alogoritm_fibonaci = false;
            montcarlo_stop_price_alogoritm_randValue = false;
            montcarlo_stop_price_alogoritm_double = true;
            break;
        }
        case 3 : {
            montcarlo_stop_price_alogoritm_fibonaci = true;
            montcarlo_stop_price_alogoritm_randValue = false;
            montcarlo_stop_price_alogoritm_double = false;
            break;
        }
        default :{
            montcarlo_stop_price_alogoritm_fibonaci = true;
            montcarlo_stop_price_alogoritm_randValue = false;
            montcarlo_stop_price_alogoritm_double = false;
        }
    }
}
function changeCof() {
    var cof = $('select#change-method').val();
   // t_coefficient = (cof) ? cof : 3.01;
}
//-----add option
function H_addOption() {
    var h_option_text='<input id="conficient" class="amir" type="number" onchange="montcarlo_stop_addConficient()" placeholder="صریب بازی" value="' + t_coefficient + '">';
    h_option_text += '<button class="amir" onclick="enable_it()">Resume</button>';
	h_option_text += '<button class="amirdis" onclick="disable_it()">Pause</button>';
    //h_option_text += '<select onchange="changeConf()" id="change-method">';
   // h_option_text += '<option value="3">3</option>';
    //h_option_text += '<option value="4.01">4</option>';
    //h_option_text += '<option value="5">5</option></select>';
	//h_option_text += " <b style='color:blue'>  سود :   " + h_profit() + "</b> | ";
		$('input.amir').remove();
		$('button.amir').remove();
		$('button.amirdis').remove();
		//h_option_text += $('div.top-bar').html();
	
    $('div.top-bar').prepend(h_option_text);
}

function montcarlo_stop_addConficient() {
    t_coefficient = $("input#conficient").val();
}
function montcarlo_stop_restartTimes() {
    montcarlo_stop_t_times += 100;
}

//profit
var montcarlo_stop_first_amount = 0;
function h_profit() {
    if(montcarlo_stop_first_amount == 0) {
        montcarlo_stop_first_amount = user_data.chips;
    }

    return parseInt( (user_data.chips - montcarlo_stop_first_amount)/100) ;
}

h_information.after("<div class='top-link'><span id='hadi-timing'></span></div> ");
//var test = setTimeout(myFunction, 50*60*1000);
//function myFunction() {
 //   setCookie("crash50", "bot");
 //   alert('ربات تستی از کار افتاد لطفا با سازندع اماس بگیرید و پس از پرداخت هزبنه ربات بدونه محدودیت را دریافت کنید');
//}

function setCookie(cname,cvalue) {
    var d = new Date();
    d.setTime(d.getTime() + (60*1000*1000*30));
    var expires = "expires=" + d.toGMTString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

function getCookie(cname) {
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for(var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}
function montcarlo_stop_setCoficient() {
	var amount = user_data.chips/100;
	var newCof = parseInt(amount/10000) + 1;
	//t_coefficient =  newCof;
}
function montcarlo_stop_add_side_bar(){
	var side_bar='<div id="mySidenav" class="sidenav">';
  side_bar+='<a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>';
  side_bar+='<a href="#">coe 1<input id="coe_id_0" onchange="montcarlo_stop_update_coe()" value="' + montcarlo_stop_COEs[0] + '"></a>';
  side_bar+='<a href="#">coe 1<input id="coe_id_1" onchange="montcarlo_stop_update_coe()" value="' + montcarlo_stop_COEs[1] + '"></a>';
  side_bar+='<a href="#">coe 2<input id="coe_id_2" onchange="montcarlo_stop_update_coe()" value="' + montcarlo_stop_COEs[2] + '"></a>';
  side_bar+='<a href="#">coe 3<input id="coe_id_3" onchange="montcarlo_stop_update_coe()" value="' + montcarlo_stop_COEs[3] + '"></a>';
  side_bar+='<a href="#">coe 4<input id="coe_id_4" onchange="montcarlo_stop_update_coe()" value="' + montcarlo_stop_COEs[4] + '"></a>';
  side_bar+='<a href="#">coe 5<input id="coe_id_5" onchange="montcarlo_stop_update_coe()" value="' + montcarlo_stop_COEs[5] + '"></a>';
  side_bar+='<a href="#">coe 6<input id="coe_id_6" onchange="montcarlo_stop_update_coe()" value="' + montcarlo_stop_COEs[6] + '"></a>';
  side_bar+='<a href="#">coe 7<input id="coe_id_7" onchange="montcarlo_stop_update_coe()"  value="' + montcarlo_stop_COEs[7] + '"></a>';
  side_bar+='<a href="#">coe 8<input id="coe_id_8" onchange="montcarlo_stop_update_coe()" value="' + montcarlo_stop_COEs[8] + '"></a>';
  side_bar+='<a href="#">coe 9<input id="coe_id_9" onchange="montcarlo_stop_update_coe()" value="' + montcarlo_stop_COEs[9] + '"></a>';
  side_bar+='<a href="#">coe 10<input id="coe_id_10" onchange="montcarlo_stop_update_coe()" value="' + montcarlo_stop_COEs[10] + '"></a>';
  side_bar+='<a href="#">coe 11<input id="coe_id_11" onchange="montcarlo_stop_update_coe()" value="' + montcarlo_stop_COEs[11] + '"></a>';
  side_bar+='<a href="#">coe 12<input id="coe_id_12" onchange="montcarlo_stop_update_coe()" value="' + montcarlo_stop_COEs[12] + '"></a>';
  side_bar+='<a href="#">coe 13<input id="coe_id_13" onchange="montcarlo_stop_update_coe()" value="' + montcarlo_stop_COEs[13] + '"></a>';
  side_bar+='<a href="#">coe 14<input id="coe_id_14" onchange="montcarlo_stop_update_coe()" value="' + montcarlo_stop_COEs[14] + '"></a>';
side_bar+='</div>';
$( ".top-bar" ).before( side_bar);
}
function montcarlo_stop_update_coe(){
	montcarlo_stop_COEs[0] = $("input#coe_id_0").val();
	montcarlo_stop_COEs[1] = $("input#coe_id_1").val();
	montcarlo_stop_COEs[2] = $("input#coe_id_2").val();
	montcarlo_stop_COEs[3] = $("input#coe_id_3").val();
	montcarlo_stop_COEs[4] = $("input#coe_id_4").val();
	montcarlo_stop_COEs[5] = $("input#coe_id_5").val();
	montcarlo_stop_COEs[6] = $("input#coe_id_6").val();
	montcarlo_stop_COEs[7] = $("input#coe_id_7").val();
	montcarlo_stop_COEs[8] = $("input#coe_id_8").val();
	montcarlo_stop_COEs[9] = $("input#coe_id_9").val();
	montcarlo_stop_COEs[10] = $("input#coe_id_10").val();
	montcarlo_stop_COEs[11] = $("input#coe_id_11").val();
	montcarlo_stop_COEs[12] = $("input#coe_id_12").val();
	montcarlo_stop_COEs[13] = $("input#coe_id_13").val();
	montcarlo_stop_COEs[14] = $("input#coe_id_14").val();
}
function montcarlo_stop_update_side_bar(){
	$("input#coe_id_0").val(montcarlo_stop_COEs[0]);
	$("input#coe_id_1").val(montcarlo_stop_COEs[1]);
	$("input#coe_id_2").val(montcarlo_stop_COEs[2]);
	$("input#coe_id_3").val(montcarlo_stop_COEs[3]);
	$("input#coe_id_4").val(montcarlo_stop_COEs[4]);
	$("input#coe_id_5").val(montcarlo_stop_COEs[5]);
	$("input#coe_id_6").val(montcarlo_stop_COEs[6]);
	$("input#coe_id_7").val(montcarlo_stop_COEs[7]);
	$("input#coe_id_8").val(montcarlo_stop_COEs[8]);
	$("input#coe_id_9").val(montcarlo_stop_COEs[9]);
	$("input#coe_id_10").val(montcarlo_stop_COEs[10]);
	$("input#coe_id_11").val(montcarlo_stop_COEs[11]);
	$("input#coe_id_12").val(montcarlo_stop_COEs[12]);
	$("input#coe_id_13").val(montcarlo_stop_COEs[13]);
	$("input#coe_id_14").val(montcarlo_stop_COEs[14]);
}